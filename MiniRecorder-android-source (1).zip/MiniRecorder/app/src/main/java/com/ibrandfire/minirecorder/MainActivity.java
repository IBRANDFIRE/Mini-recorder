package com.ibrandfire.minirecorder;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Mini Recorder: a thin native shell around the web app in assets/index.html.
 * The page is served from a secure https origin (WebViewAssetLoader) so the camera works.
 * Recordings and photos are written to the gallery through the "AndroidBridge" JS interface.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_PERMS = 7;

    private WebView web;
    private WebViewAssetLoader loader;
    private PermissionRequest pending;
    private boolean asking = false;

    private final Map<Integer, SaveJob> jobs = new ConcurrentHashMap<>();
    private final AtomicInteger ids = new AtomicInteger(1);

    private volatile String lastError = "";
    private volatile String lastLocation = "";

    private static class SaveJob {
        Uri uri;
        java.io.File file;
        OutputStream os;
        String where = "";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);

        loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOST.equals(request.getUrl().getHost());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> answer(request, true));
            }
        });

        web.loadUrl("https://" + HOST + "/assets/index.html");
        immersive();
        askPermissions();
    }

    // ---------- permissions ----------

    private void askPermissions() {
        if (asking) return;
        List<String> need = new ArrayList<>();
        String[] all = {Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO};
        for (String p : all) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        }
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!need.isEmpty()) {
            asking = true;
            requestPermissions(need.toArray(new String[0]), REQ_PERMS);
        }
    }

    private void answer(PermissionRequest r, boolean mayAsk) {
        if (!HOST.equals(r.getOrigin().getHost())) {
            r.deny();
            return;
        }
        List<String> ok = new ArrayList<>();
        boolean missing = false;
        for (String res : r.getResources()) {
            String perm = null;
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) perm = Manifest.permission.CAMERA;
            else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) perm = Manifest.permission.RECORD_AUDIO;
            if (perm == null) continue;
            if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) ok.add(res);
            else missing = true;
        }
        if (missing && mayAsk && pending == null) {
            pending = r;
            askPermissions();
            if (!asking) { // nothing to ask for after all
                pending = null;
                finishAnswer(r, ok);
            }
            return;
        }
        finishAnswer(r, ok);
    }

    private void finishAnswer(PermissionRequest r, List<String> ok) {
        if (ok.isEmpty()) r.deny();
        else r.grant(ok.toArray(new String[0]));
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        asking = false;
        if (pending != null) {
            PermissionRequest r = pending;
            pending = null;
            answer(r, false);
        }
    }

    // ---------- window, keys, lifecycle ----------

    private void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    /** Volume keys act as a shutter button (photo). */
    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        if (k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
                web.evaluateJavascript("window.onVolumeKey&&window.onVolumeKey()", null);
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.onAndroidBack?window.onAndroidBack():false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }

    // ---------- JavaScript bridge: save to gallery, share ----------

    public class Bridge {

        @JavascriptInterface
        public boolean isApp() {
            return true;
        }

        @JavascriptInterface
        public String lastError() {
            return lastError;
        }

        @JavascriptInterface
        public String lastLocation() {
            return lastLocation;
        }

        /**
         * Starts a file. kind = "image" or "video". Returns a job id, or -1 on failure.
         * Tries the gallery (MediaStore) first; if that fails, falls back to the app's own folder
         * so a recording is never lost.
         */
        @JavascriptInterface
        public int saveBegin(String name, String mime, String kind) {
            boolean image = "image".equals(kind);
            String dirName = image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_MOVIES;
            String firstError;
            Uri created = null;
            try {
                if (Build.VERSION.SDK_INT < 29
                        && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    throw new SecurityException("storage permission not granted");
                }
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                if (Build.VERSION.SDK_INT >= 29) {
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, dirName + "/MiniRecorder");
                    v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                } else {
                    java.io.File dir = new java.io.File(Environment.getExternalStoragePublicDirectory(dirName), "MiniRecorder");
                    if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("cannot create " + dir);
                    v.put(MediaStore.MediaColumns.DATA, new java.io.File(dir, name).getAbsolutePath());
                }
                Uri base = image ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                                 : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                Uri uri = getContentResolver().insert(base, v);
                if (uri == null) throw new IllegalStateException("gallery insert returned null");
                created = uri;
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) throw new IllegalStateException("gallery stream is null");
                SaveJob job = new SaveJob();
                job.uri = uri;
                job.os = new BufferedOutputStream(os, 1 << 16);
                job.where = dirName + "/MiniRecorder";
                int id = ids.getAndIncrement();
                jobs.put(id, job);
                return id;
            } catch (Throwable e) {
                firstError = String.valueOf(e);
                if (created != null) {
                    try {
                        getContentResolver().delete(created, null, null);
                    } catch (Throwable ignored) {
                    }
                }
            }
            try {
                java.io.File dir = getExternalFilesDir(dirName);
                if (dir == null) dir = new java.io.File(getFilesDir(), dirName);
                if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("cannot create " + dir);
                java.io.File f = new java.io.File(dir, name);
                SaveJob job = new SaveJob();
                job.file = f;
                job.os = new BufferedOutputStream(new java.io.FileOutputStream(f), 1 << 16);
                job.where = "app folder " + dir.getAbsolutePath();
                int id = ids.getAndIncrement();
                jobs.put(id, job);
                lastError = "gallery failed (" + firstError + ")";
                return id;
            } catch (Throwable e2) {
                lastError = firstError + " | " + e2;
                return -1;
            }
        }

        @JavascriptInterface
        public boolean saveChunk(int id, String base64) {
            SaveJob job = jobs.get(id);
            if (job == null) {
                lastError = "unknown save job";
                return false;
            }
            try {
                job.os.write(Base64.decode(base64, Base64.DEFAULT));
                return true;
            } catch (Throwable e) {
                lastError = String.valueOf(e);
                return false;
            }
        }

        /** Finishes the file and returns its location ("" on failure). */
        @JavascriptInterface
        public String saveEnd(int id) {
            SaveJob job = jobs.remove(id);
            if (job == null) {
                lastError = "unknown save job";
                return "";
            }
            try {
                job.os.flush();
                job.os.close();
                lastLocation = job.where;
                if (job.file != null) {
                    return "file:" + job.file.getAbsolutePath();
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(job.uri, v, null, null);
                }
                return job.uri.toString();
            } catch (Throwable e) {
                lastError = String.valueOf(e);
                return "";
            }
        }

        @JavascriptInterface
        public void saveAbort(int id) {
            SaveJob job = jobs.remove(id);
            if (job == null) return;
            try {
                job.os.close();
            } catch (Throwable ignored) {
            }
            try {
                if (job.file != null) job.file.delete();
                else getContentResolver().delete(job.uri, null, null);
            } catch (Throwable ignored) {
            }
        }

        @JavascriptInterface
        public void share(final String uri, final String mime) {
            runOnUiThread(() -> {
                try {
                    if (uri == null || uri.startsWith("file:")) {
                        Toast.makeText(MainActivity.this, "Sharing is not available for files in the app folder", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType(mime == null || mime.isEmpty() ? "video/*" : mime);
                    i.putExtra(Intent.EXTRA_STREAM, Uri.parse(uri));
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "Share"));
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }
}
