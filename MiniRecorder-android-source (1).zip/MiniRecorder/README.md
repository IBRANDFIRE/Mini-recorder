# Mini Recorder (Android app)

A native Android shell around the Mini Recorder web app (`app/src/main/assets/index.html`).
It adds real camera and microphone permissions, saves videos to **Movies/MiniRecorder** and photos to **Pictures/MiniRecorder**, and uses the volume keys as a photo shutter.

Needs Android 8.0 or newer (minSdk 26).

## Build the APK with GitHub Actions

1. Create a new GitHub repository and put every file of this project in it (keep the folder layout, including the hidden `.github/workflows/build-apk.yml` and `app/release.keystore`).
2. Push to the `main` branch. The workflow **Build Android APK** starts by itself. You can also start it from the Actions tab with "Run workflow".
3. When it finishes (about 4 to 6 minutes), download the APK from either place:
   - the repository's **Releases** page (easiest on a phone), or
   - the run page, under **Artifacts**.
4. Open the APK on your phone and allow "install unknown apps" if asked.

### Pushing from a phone with Termux

```
pkg install git unzip
unzip MiniRecorder-android-source.zip && cd MiniRecorder
git init -b main && git add -A && git commit -m "Mini Recorder"
git remote add origin https://github.com/YOUR_NAME/YOUR_REPO.git
git push -u origin main      # use a personal access token as the password
```

## Installing the APK

- Download the `.apk` from the repository's **Releases** page (Assets list). Do not install the `.zip` you get from the Actions "Artifacts" section: unzip it first, then install the `.apk` inside.
- If Android says "problem parsing the package", the file is usually not a complete `.apk` (wrong download, a zip, or an HTML page), or the phone runs Android older than 8.0.

## Signing and updates

The project includes `app/release.keystore` (password and alias: `minirecorder`). Every build is signed with it, so a new build installs over the old one without uninstalling. Version numbers increase automatically with each run.

To use your own key instead, add these repository secrets (Settings, Secrets and variables, Actions). The workflow picks them up automatically:

| Secret | Value |
| --- | --- |
| `KEYSTORE_BASE64` | your keystore file as base64 (`base64 -w0 my.keystore`) |
| `KEYSTORE_PASSWORD` | keystore password |
| `KEY_ALIAS` | key alias |
| `KEY_PASSWORD` | key password (optional, defaults to the keystore password) |

Keep a private copy of your own keystore. If you lose it you cannot update installed copies.

## Updating the web app

Replace `app/src/main/assets/index.html` with a new version of the web app and push. The next build contains it.

## How it works

- `MainActivity.java` loads the page from `https://appassets.androidplatform.net/assets/index.html` (WebViewAssetLoader), which counts as a secure origin, so the camera works.
- Camera and microphone prompts are answered through `WebChromeClient.onPermissionRequest`.
- The page saves files through the `AndroidBridge` interface in chunks, so long videos do not need to fit in one message.
- Back button closes panels first and only leaves the app when nothing is open. Leaving the app while recording stops and keeps the recording.

## Local build (optional)

Install JDK 17 and the Android SDK, then run `gradle assembleRelease` (Gradle 8.9). To add a Gradle wrapper, run `gradle wrapper --gradle-version 8.9` once.
